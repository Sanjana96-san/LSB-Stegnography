/* name : sanjana B
 * date : 9/10/2024
 * description : function defination for decoding
 * sample execution -->  ./a.out -d stego.bmp
 * YES you started DECODING
1.Read and validate arg is sucessfull
opening file is successfull
1.opened files successfully
2.decoded magic string is completed
3.decoded extension size is completed
4.secret file decoded extension size is completed
5.opening of  output decoded file completed
6.secret file size decoded completed
secret file decoded successfully
7.secret file data decoded successfully
FINAL -> DECODING is sucess*/


#include <stdio.h>
#include<string.h>
#include"common.h"
#include "decode.h"
#include<stdlib.h>
#include<unistd.h>
#include "types.h"


/*Function to read and validate the arguments*/
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo)//1
{
		if(strstr(argv[2],".bmp") != NULL)
		{
				decInfo -> src_image_fname = argv[2]; // storing the file name
				if(argv[3] == NULL)
				{
						decInfo->secret_fname = "output"; // default name 
						return e_success;
				}
				else
				{
						decInfo->secret_fname  = argv[3];
						return e_success;
				}
		}
        return e_failure;
}
/*Function to open the files*/
Status open_files_for_decoding(DecodeInfo *decInfo)
{
		sleep(1);
        printf("opening file is successfull\n");
        decInfo->fptr_src_image = fopen(decInfo->src_image_fname, "rb");//open in read mode
        if (decInfo->fptr_src_image == NULL)//check src have any data or not
       {
       		   perror("fopen");
       		   fprintf(stderr,"ERROR: Unable to open file %s\n", decInfo->src_image_fname);
       		   return e_failure;
	}
	return e_success;
}
/*Function decoing the magic string*/
Status decode_magic_string(DecodeInfo *decInfo)
{
		char *decoded_magic_string = (char *)malloc((strlen(MAGIC_STRING)+1) * sizeof(char)); // dynamically allocating the memory to the string
		if(decoded_magic_string == NULL)
		{
				printf("INFO: ERROR:unable to allocate memory for decoded magic string\n");
                return e_failure;
        }
        fseek(decInfo->fptr_src_image,54,SEEK_SET); // to start from the header
        if(decode_image_to_data(decInfo,decoded_magic_string,strlen(MAGIC_STRING)) == e_success) // checking for the magic string
        {    
        		decoded_magic_string[strlen(MAGIC_STRING)] = '\0'; // tracing upto null
        		if(strcmp(decoded_magic_string,MAGIC_STRING) == 0) // comparing the encoded '#*' to eql or not
                {
                    free(decoded_magic_string);
                    return e_success;
                }
                else
                {
                     printf("INFO:ERROR:magic string not decoded correctly\n");
                     free(decoded_magic_string);
                     return e_failure;
                }
       }
       free(decoded_magic_string);
       return e_failure;
}

/*Function to decode the image to data */
Status decode_image_to_data(DecodeInfo *decInfo,char *data,int size)
{
	char image_buffer[8];
	int i;
	for(i = 0;i < size;i++) // size may be 8 or 32
	{
			fread(image_buffer,8,1,decInfo->fptr_src_image); // reading from the src to buff
			decode_byte_to_lsb(&data[i],image_buffer);		
	}
	return e_success;

}
/*Function to decode msb to lsb */
Status decode_byte_to_lsb(char *data,char *image_buffer)
{
		*data = 0;
		int i;
		for(i = 0;i < 8;i++)
		{
				*data |= (image_buffer[i] &1) << (7-i); // msb to lsb bitwise
        }
        return e_success;
}
/*function to decode the size to lsb*/
Status decode_size_to_lsb(int *size,char *image_buffer)//7
{
		*size = 0;
		int i;
		for(i= 0;i < 32;i++)
		{
				*size |= (image_buffer[i] & 1) << (31-i); // msb to lsb bitwise operation
	  }
          return e_success;
}
/*function to decode the secret file size*/
Status decode_secret_file_extn_size(DecodeInfo *decInfo)
{
		int size;
		char size_buffer[32];
		fread(size_buffer,32,1,decInfo->fptr_src_image); // reading from src to buf
		decode_size_to_lsb(&size,size_buffer);// fucn call
		decInfo->extn_secret_file_size = size; // storing it to extn size
		return e_success;
}
/*Function to decode the secret file extension*/
Status decode_secret_file_extn(DecodeInfo *decInfo)
{
		if(decode_image_to_data(decInfo,decInfo->extn_secret_file,decInfo->extn_secret_file_size) == e_success) // calling the data to image
		{
		     return e_success;
		}
      return e_failure;
}
/*function to decode the secret file size*/
Status decode_secret_file_size(DecodeInfo *decInfo)
{
		if(decode_secret_file_extn_size(decInfo) == e_success) // calling 
		{
				return e_success;
		}
		return e_failure;
}
/*function to decode the secret file data*/
Status decode_secret_file_data(DecodeInfo *decInfo)
{
		char *data = (char *) malloc(decInfo->extn_secret_file_size); // allocating memory
        if(data == NULL)
        {
        		printf("ERROR:unable to allocate memory for data\n");
        		return e_failure; 
         }
        if(decode_image_to_data(decInfo,data,decInfo->extn_secret_file_size) == e_success)
        {
            printf("secret file decoded successfully\n");
            fwrite(data,decInfo->extn_secret_file_size,1,decInfo->fptr_secret);
            return e_success;
         }
         free(data);
         return e_failure;
        
}
/* function for opeing the output files*/
Status open_output_file(DecodeInfo *decInfo,char *argv[])
{
		char full_output_fname[50],secret_fname_copy[50];
		strcpy(secret_fname_copy,decInfo->secret_fname);// copying the data
		char *token = strtok(secret_fname_copy,".");
		if(token != NULL)
		{
				strcpy(full_output_fname,token);
		}
		else
		{
				strcpy(full_output_fname,decInfo->secret_fname);
		}
		strcat(full_output_fname,decInfo->extn_secret_file); // merging the file name and extension
		decInfo->fptr_secret = fopen(full_output_fname,"w"); // opeing in write mode
		if(decInfo->fptr_secret == NULL)
		{
				printf("ERROR:unable to open file %s\n",full_output_fname);
				return e_failure;
		}
		return e_success;
} 
/*function for decoding*/
Status do_decoding(DecodeInfo *decInfo,char *argv[])
{
		if( open_files_for_decoding(decInfo) == e_success) /*step1:opening the files*/
		{
				sleep(1);
				printf("1.opened files successfully\n");
				if (decode_magic_string(decInfo)==e_success) /*step2 : decoding the magic string*/
				{
						sleep(1);
						printf("2.decoded magic string is completed\n");
						if(decode_secret_file_extn_size(decInfo) == e_success)/*step3 : decoding the extn size*/
						{
								sleep(1);
								printf("3.decoded extension size is completed\n");
								if(decode_secret_file_extn(decInfo) == e_success) /*step4 : decoding the fileextn*/
								{
										sleep(1);
										printf("4.secret file decoded extension size is completed\n");
										if(open_output_file(decInfo ,argv) == e_success) /*step5: opeing the output files*/
                                        {
                                        		sleep(1);
                                        		printf("5.opening of  output decoded file completed\n");
                                        		if(decode_secret_file_size(decInfo) == e_success) /*step6 : decoding the file size*/
                                        		{
                                        				sleep(1);
                                        				printf("6.secret file size decoded completed\n");
                                        				if(decode_secret_file_data(decInfo) == e_success)/*step7 : decoding the file data*/
                                        	            {
                                        	            		sleep(1);
                                                                printf("7.secret file data decoded successfully\n");
                                                                return e_success;
                                                          }
                                                        else
														{
																printf("error : secret file data decoding failed\n");
														}
												}
												else
												{
														printf("error : secret file data size decoding failed\n");
												}
										}
										else
										{
												printf("error:open file decoded failed\n");
										}
								}
								else
								{
										printf("error : secret file extension decoding failed\n");    
								}
						}
						else
						{
								printf("error : secret file extension size decoding failed\n");
						}
				}
				else
				{
						printf("error : magic string decoding failed\n");
				}
		}
		else
		{
				printf("error : coping header failed\n");
		}
        fclose(decInfo->fptr_src_image); // closing the files
        fclose(decInfo->fptr_secret);
        return e_failure;
}








