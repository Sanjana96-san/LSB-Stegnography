/*Name : sanjana B
 * date : 09/10/2024
 * description : main function for both encoding and decoding*/


#include <stdio.h>
#include "encode.h"
#include "decode.h"
#include "types.h"

int main(int argc,char **argv)
{
		if(argc >= 3)
		{
				int res = check_operation_type(argv);
				if(res == e_encode)
				{
						EncodeInfo encInfo;
						printf("YES you started ENCODING\n");
						if(read_and_validate_encode_args(argv,&encInfo) == e_success)
						{
								printf("1.Read and validate arg is sucessfull\n");
								if(do_encoding(&encInfo) == e_success)
								{
										printf("FINAL -> ENCODING is sucess\n");
										return e_success;
								}
								else
								{
										printf("Error : Encoding is failure\n");
										return e_failure;
								}
						}
						else
						{
								printf("Error : read and validated failed\n");
								return e_failure;
						}
				}
				else if(res == e_decode)
				{
						DecodeInfo decInfo;
						printf("YES you started DECODING\n");
						if(read_and_validate_decode_args(argv,&decInfo) == e_success)
						{
								printf("1.Read and validate arg is sucessfull\n");
								if(do_decoding(&decInfo,argv) == e_success)
								{
										printf("FINAL -> DECODING is sucess\n");
										return e_success;
								}
								else
								{
										printf("Error : Decoding is failure\n");
										return e_failure;
								}
						}
						else
						{
								printf("Error : read and validated failed\n");
								return e_failure;
						}
				}
				else
				{
						printf("Error : check operation failed\n");
						return e_failure;
				}
		}
		else
		{
				return e_unsupported;
		}
}
				


