/* Name : sanjana B
 * date : 09/10/2024
 * description : function definiton for the encoding 
 * sample execution --> $ ./a.out -e beautiful.bmp secret.txt
YES you started ENCODING
1.Read and validate arg is sucessfull
1.Opened every files Successfully
width = 1024
height = 768
2.Capacity of the image file is Successfully
3.Header copied from the Source image successfully
4.successfully encoded magic string
5.successfully encoded extension size
6.successfully secret file encoded extension size
7.successfully encoded secret file size
8.successfully encoded secret file data
9.successfully encoded remaining data completed
FINAL -> ENCODING is sucess */


#include <stdio.h>
#include<string.h>
#include"common.h"
#include "encode.h"
#include "types.h"
#include<unistd.h>

/* Function Definitions */

/* Get image size
 * Input: Image file ptr
 * Output: width * height * bytes per pixel (3 in our case)
 * Description: In BMP Image, width is stored in offset 18,
 * and height after that. size is 4 bytes
 */
uint get_image_size_for_bmp(FILE *fptr_image)
{
		uint width, height;
    // Seek to 18th byte
        fseek(fptr_image, 18, SEEK_SET);

    // Read the width (an int)
        fread(&width, sizeof(int), 1, fptr_image);
        printf("width = %u\n", width);

    // Read the height (an int)
       fread(&height, sizeof(int), 1, fptr_image);
       printf("height = %u\n", height);

    // Return image capacity
       return width * height * 3;
}
uint get_file_size(FILE *fptr,EncodeInfo *encInfo)
{
		fseek(fptr,0,SEEK_END);
		encInfo->size_secret_file=ftell(fptr);
		return ftell(fptr);
}
/* 
 * Get File pointers for i/p and o/p files
 * Inputs: Src Image file, Secret file and
 * Stego Image file
 * Output: FILE pointer for above files
 * Return Value: e_success or e_failure, on file errors
 */
Status open_files(EncodeInfo *encInfo)
{
    // Src Image file
       encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "r");
    // Do Error handling
       if (encInfo->fptr_src_image == NULL)
       {
       		   perror("fopen");
       		   fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);
       		   return e_failure;
	   }

    // Secret file
       encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");
    // Do Error handling
    if (encInfo->fptr_secret == NULL)
    {
    		perror("fopen");
    	    fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);
    	    return e_failure;
    }

    // Stego Image file
       encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "w");
    // Do Error handling
    if (encInfo->fptr_stego_image == NULL)
    {
    		perror("fopen");
    		fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->stego_image_fname);
    		return e_failure;
    }

    // No failure return e_success
          return e_success;
}
/* Function for Checking the agrument */
OperationType check_operation_type( char *argv[])
{
		if( strcmp( argv[1] , "-e") == 0) /*checkinf for arguments encode or decode */ 
		{
				return e_encode ;
		}
		else if( strcmp ( argv[1], "-d") == 0)
		{
				return e_decode;
		}
		else
		{
				return e_unsupported ;
		}
}
/*Function to read and validate the agruments*/
Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo)
{
		if(strstr(argv[2],".bmp") != NULL)
		{
				encInfo -> src_image_fname = argv[2]; // stroing the file
				if((strstr(argv[3],".txt") != NULL) || (strstr(argv[3],".c") != NULL) || (strstr(argv[3],".sh") != NULL))
				{           
						encInfo -> secret_fname = argv[3];
						strcpy(encInfo->extn_secret_file,strstr(argv[3],".txt")); // storing the file 
						if(argv[4] == NULL)
						{
								encInfo->stego_image_fname = "stego.bmp" ; // default name 
								return e_success;
						}
						else
						{
								if(strstr(argv[4],".bmp") != NULL)
										encInfo -> stego_image_fname = argv[4];
								return e_success ;
						}
				}
				else
				{
						return e_failure;
				}
		}
		else 
		{
				return e_failure;
		}
}
/*Function to encoding size to lsb */
Status encode_size_to_lsb(int size,char *image_buffer)
{
		int i;
		unsigned int data = (unsigned int) size;
		for(i = 0;i < 32;i++)
        {
        		image_buffer[i] = (image_buffer[i] & ~1 |((data & (1 << 31 - i)))>> 31 -i); // msb to lsb bit wise
        }
        return e_success ;
}     
/*Function to encode the file extension size*/
Status encode_extn_size(int size,EncodeInfo *encInfo)
{
		char image_buffer[32];
		int i;
		fread(image_buffer,32,1,encInfo->fptr_src_image); // reading the byte from src to buff
		encode_size_to_lsb(size, image_buffer); // calling the size to lsb 
		fwrite(image_buffer,32,1,encInfo->fptr_stego_image);// writting into the stego
		return e_success;
}
/* Function to check the image size capacity*/
Status check_capacity(EncodeInfo *encInfo)
{
		int val=(54+ ((strlen(MAGIC_STRING)+4+strlen(strstr(encInfo->secret_fname,".")+0+get_file_size(encInfo->fptr_secret,encInfo))*8))); // getting the 54 header and then rgb
           if(val < get_image_size_for_bmp(encInfo->fptr_src_image)) // checking size of the output img with input img
           return e_success;
}
/*Function to copy the 54 header */
Status copy_bmp_header(FILE *fptr_src_image,FILE *fptr_dest_image)
{
		char buffer[54];
		rewind(fptr_src_image); // to rewind it to starting 0
		fread(buffer,54,1,fptr_src_image);
		rewind(fptr_dest_image); // to rewind it to start 0
		fwrite(buffer,54,1,fptr_dest_image);
		return e_success ;
}
/*Function to Encode the MAGIC STRING*/
Status encode_magic_string(const char *magic_string,EncodeInfo *encInfo)
{
		return encode_data_to_image(MAGIC_STRING,strlen(MAGIC_STRING),encInfo->fptr_src_image,encInfo->fptr_stego_image);
}
/*Function to encode data from the image*/
Status encode_data_to_image(char *data,int size,FILE *fptr_src_image,FILE *fptr_stego_image)
{
		char image_buffer[8];
		int i;
        for(i = 0;i < size;i++) // size may be 8 or 32(char or int)
        {
        		fread(image_buffer,8,1,fptr_src_image); 
                encode_byte_to_lsb(data[i],image_buffer); // calling the function 
                fwrite(image_buffer,8,1,fptr_stego_image);
		}
		return e_success ;
}
/* function to encode byte form the msb to lsb*/
Status encode_byte_to_lsb(char data,char *image_buffer)
{
		int i;
		for(i = 0;i < 8;i++)
		{
				image_buffer[i] = (image_buffer[i] & ~1 | (data & (1<<7-i)) >> 7-i); // the bitwise operation from msb to lsb
		}
		return e_success ;

}
/*Function encode the secret file size (25 here)*/
Status encode_secret_file_size(long file_size,EncodeInfo *encInfo)
{
		char image_buffer[32];
        int i;
        fread(image_buffer,32,1,encInfo->fptr_src_image); // read the data from the src to buff
        encode_size_to_lsb(file_size, image_buffer);// calling the func  
        fwrite(image_buffer,32,1,encInfo->fptr_stego_image); // writing the data to stego
        return e_success ;
}
/* Function encode the secret file extension like .txt or .c or .sh*/
Status encode_secret_file_extn(const char *file_extn , EncodeInfo *encInfo)
{
     //size_to_lsb(file_size , encInfo->secret_data);
      encode_data_to_image(encInfo->extn_secret_file,strlen(encInfo->extn_secret_file),encInfo->fptr_src_image,encInfo->fptr_stego_image);
      return e_success;
}  
/*Function encoding the secret file data*/
Status encode_secret_file_data(EncodeInfo *encInfo)
{
		rewind(encInfo->fptr_secret);// rewinding the file * to start
		char arr[encInfo->size_secret_file]; // storing into one array
		fread(arr,encInfo->size_secret_file,1,encInfo->fptr_secret); // reading stored array into secret file 
		encode_data_to_image(arr,encInfo->size_secret_file,encInfo->fptr_src_image,encInfo->fptr_stego_image);// calling function
		return e_success;
}
/*Function copying the remaining data */
Status copy_remaining_img_data(FILE *fptr_src,FILE *fptr_dest)
{
		char buffer[4096]; // to store the data 
		int bytes_read; 
		if(fptr_src == NULL || fptr_dest == NULL)
		{
				printf("error : Invalid file pointer mismatching\n");
				return e_failure;
		}
		long off = ftell(fptr_src);
		fseek(fptr_src,off,SEEK_SET); // to get from the that position
		while((bytes_read = fread(buffer,1,sizeof(buffer),fptr_src))) // reading and wrting to the stego every message
		{
				fwrite(buffer,1,bytes_read,fptr_dest);
		}
		return e_success;
}

/*function to encode the process*/
Status do_encoding(EncodeInfo *encInfo)
{
		if( open_files(encInfo) == e_success) /*step1 : opening the files*/
		{
				sleep(1);
				printf("1.Opened every files Successfully\n");
				if(check_capacity(encInfo) == e_success) /*step2 : checking the capacity of img*/
				{
						sleep(1);
						printf("2.Capacity of the image file is Successfully\n");
						if(copy_bmp_header(encInfo->fptr_src_image,encInfo->fptr_stego_image) == e_success) /*step3 : coping the header*/
					    {
					    		sleep(1);
					    		printf("3.Header copied from the Source image successfully\n");
                            if (encode_magic_string(MAGIC_STRING,encInfo)==e_success) /*step4:encoding magic string*/
                            {
                            		sleep(1);
                            		printf("4.successfully encoded magic string\n");
                                    if(encode_extn_size(strlen(encInfo->extn_secret_file),encInfo) == e_success) /*step5 : encoding extension size*/
                                    {
                                    		sleep(1);
                                    		printf("5.successfully encoded extension size\n");
                                            if(encode_secret_file_extn(encInfo->secret_fname,encInfo) == e_success) /*step6  : encoding file extension*/
                                            {
                                            		sleep(1);
                                            		printf("6.successfully secret file encoded extension size\n");
                                       if(encode_secret_file_size(encInfo->size_secret_file,encInfo) == e_success) /*step7 : encoding file size*/
                                       {
                                       		   sleep(1);
                                       		   printf("7.successfully encoded secret file size\n");
                                       		   if(encode_secret_file_data(encInfo) == e_success) /*step8 : encode the secret file data*/
                                                {
                                                		sleep(1);
                                                        printf("8.successfully encoded secret file data\n");
                                                       if(copy_remaining_img_data(encInfo->fptr_src_image,encInfo->fptr_stego_image) == e_success) /*step9 : copy remaining the data*/
                                                        {
                                                                sleep(1);
                                                                printf("9.successfully encoded remaining data completed\n");
                                                                return e_success ;
                                                        } 
														else
												        {
																printf("Encoding remaining data failed\n");
														}
												}
											   else
											   {
											   		   printf("failed to encode the secret file data\n");
											   }
									   }
									   else
									   {
									   		   printf("failed encode the secret file size\n");
									   }
									   		}
											else
											{
													printf("failed encode the secret file extension size\n");
											}
									}
									else
									{
											printf("failed to encode the magic string\n");
									}
                     }
							else
							{
									printf("failed check the capacity\n");
							}
               }
						else
						{
								printf("failed to open the files\n");
						}
				}
		}
}
     


 
